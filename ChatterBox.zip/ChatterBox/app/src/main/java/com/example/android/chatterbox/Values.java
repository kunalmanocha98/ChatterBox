package com.example.android.chatterbox;

/**
 * Created by Kunal on 10-Nov-17.
 */

public class Values {
    String regnumber;
    String message;

    public void setRegnumber(String regnumber) {
        this.regnumber = regnumber;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getRegnumber() {
        return regnumber;
    }

    public String getMessage() {
        return message;
    }


}
